from nicegui import ui, run
import pandas as pd
import datetime
from components.grafico_mapa import plot_mapa_faturamento
from components.grafico_marketplace import plot_pizza_marketplace, calcular_valor_total_faturado
from components.grafico_categoria import plot_faturamento_por_categoria
from utils import load_data
from queries import (
    get_orders_query,
    get_top_10_produtos_query,
    get_mapa_query,
    get_categorias_query,
)
from nicegui import app

async def show_dashboard():
    session = app.storage.user
    schema = session.get("schema")
    if not schema:
        ui.label("Sessão expirada. Faça login novamente.")
        return

    with ui.row().classes("w-full justify-between"):
        ui.label(f"Bem-vindo ao Dashboard, {session.get('username')}").classes("text-2xl")
        ui.label(f"Schema: {schema}").classes("text-sm text-gray-500")

    with ui.row().classes("w-full gap-4 mt-4"):
        faturamento_total = calcular_valor_total_faturado(schema)
        if faturamento_total is not None:
            ui.label(f"Faturamento total: R$ {faturamento_total:,.2f}").classes("text-lg")

    with ui.row().classes("w-full mt-6"):
        start_date = datetime.datetime.now().replace(day=1)
        end_date = datetime.datetime.now()
        with ui.column().classes("w-1/2"):
            df_categoria = get_categorias_query(schema)
            plot_faturamento_por_categoria(schema, start_date, end_date)

        with ui.column().classes("w-1/2"):
            df_marketplace = get_orders_query(schema)
            plot_pizza_marketplace(df_marketplace)

    with ui.row().classes("w-full mt-6"):
        df_mapa = get_mapa_query(schema)
        plot_mapa_faturamento(df_mapa)

    with ui.row().classes("w-full mt-6"):
        df_top10 = get_top_10_produtos_query(schema)
        if not df_top10.empty:
            with ui.table(columns=[{'name': c, 'label': c, 'field': c} for c in df_top10.columns],
                          rows=df_top10.to_dict("records"),
                          row_key='Produto').classes("w-full"):
                pass
        else:
            ui.label("Nenhum dado de produto encontrado.")