from nicegui import ui, app
from auth import get_user, verify_password

async def login_page():
    with ui.card().classes('absolute-center'):
        ui.image('Logo.png').classes('w-48')
        ui.label('Login - HelpSeller Dashboard').classes('text-xl')

        username = ui.input('Usuário').props('outlined dense').classes('w-full')
        password = ui.input('Senha', password=True).props('outlined dense').classes('w-full')
        message = ui.label().classes('text-red-500')

        def tentar_login():
            user = get_user(username.value)
            if user and verify_password(password.value, user[1]):
                app.storage.user.update({
                    'username': username.value,
                    'schema': user[2],
                    'is_master': user[3],
                })
                ui.notify('✅ Login realizado com sucesso')
                ui.navigate.to('/dashboard')
            else:
                message.text = '❌ Usuário ou senha incorretos'

        ui.button('Entrar', on_click=tentar_login).classes('w-full mt-4')