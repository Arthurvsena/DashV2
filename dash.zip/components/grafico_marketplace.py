import plotly.express as px
import pandas as pd
from nicegui import ui
from queries import get_order_item_query

def calcular_valor_total_faturado(schema):
    from datetime import date

    today = date.today()
    start_date = today.replace(day=1)
    end_date = today

    df = get_order_item_query(schema, start_date, end_date)


def plot_pizza_marketplace(df):
    df["total"] = df["quantidade"] * df["preco"]
    resumo = df.groupby("marketplace")["total"].sum().reset_index()
    fig = px.pie(resumo, names="marketplace", values="total", title="Faturamento por Marketplace")
    ui.plotly(fig)