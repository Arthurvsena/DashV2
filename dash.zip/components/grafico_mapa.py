import plotly.express as px
import pandas as pd
from nicegui import ui
import json
from queries import get_mapa_query

def plot_mapa_faturamento(df_mapa):
    try:
        with open('data/brazil-states.geojson', 'r', encoding='utf-8') as f:
            geojson_data = json.load(f)

        df = df_mapa.copy()
        df['valor_total'] = df['quantidade'] * df['preco']

        mapa = px.choropleth_mapbox(df, geojson=geojson_data, locations='estado',
                                    color='valor_total', featureidkey='properties.sigla',
                                    color_continuous_scale='Viridis',
                                    mapbox_style='carto-positron',
                                    center={'lat': -14.2, 'lon': -51.9},
                                    zoom=3.5, opacity=0.7,
                                    labels={'valor_total': 'Faturamento'})

        mapa.update_layout(margin={'r':0,'t':0,'l':0,'b':0})
        ui.plotly(mapa)
    except Exception as e:
        ui.notify(f'Erro ao gerar mapa: {e}')